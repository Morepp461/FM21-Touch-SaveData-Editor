# FM21 Touch Save Editor — Android Alpha 0.2

Target: Football Manager Touch 2021 Android save files (`.fmv`).

## Current capabilities
- Opens a user-selected `.fmv` through Android's Storage Access Framework.
- Validates the outer `02 01 fmf.` signature.
- Locates and decompresses the footer Zstandard manifest.
- Parses the save name, top-level member table, nested archive member table, offsets, stored lengths and decompressed lengths.
- Searches and filters the manifest component list.
- Displays per-component metadata.
- Decompresses a selected component into the app-private cache using its Zstandard frame boundaries.
- Reports the observed `tad.` signature and raw preamble without guessing field meanings.
- Never overwrites or modifies the source save.

## Important limitations
- `tad.` is currently treated as an observed component signature only. Its fields are not assigned meanings without evidence.
- Player CA/PA/attributes, club finances, prize money and league reputation are not yet editable.
- The FMV writer/rebuilder is not implemented. Do not use this alpha to modify career saves.
- Extracted component files remain in the app-private cache and are not exported automatically.
- The next reverse-engineering step is to map records inside `game_db/.dat`, `player_stats/.dat`, `finance_manager/.dat` and competition components using controlled save snapshots.

## Build
Open this directory in Android Studio (AGP 8.7.3, Kotlin 2.0.21, compile SDK 35). The project currently has no Gradle wrapper checked in.
