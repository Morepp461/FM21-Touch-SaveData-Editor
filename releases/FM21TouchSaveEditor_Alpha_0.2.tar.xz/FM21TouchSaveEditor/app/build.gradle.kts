plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.morepp.fm21editor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.morepp.fm21editor"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0-alpha"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.github.luben:zstd-jni:1.5.6-9")
}
