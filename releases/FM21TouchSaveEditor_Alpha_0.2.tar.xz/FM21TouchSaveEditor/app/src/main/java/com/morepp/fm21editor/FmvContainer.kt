package com.morepp.fm21editor

import com.github.luben.zstd.Zstd
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.io.File
import java.io.FileOutputStream

/** Read-only FM Touch 2021 container parser. It never mutates the input save. */
data class FmvMember(
    val name: String,
    val offset: Long,
    val storedLength: Long,
    val plainLength: Long,
    val archive: String? = null
)

data class FmvManifest(
    val saveName: String,
    val topLevel: List<FmvMember>,
    val nested: List<FmvMember>,
    val footerOffset: Int
) {
    val allMembers: List<FmvMember> get() = topLevel + nested
}

object FmvContainerReader {
    private val manifestPrefix = byteArrayOf(0x02, 0x01, 0x66, 0x6d, 0x66, 0x2e, 0x08, 0x00, 0x00)
    private val zstdMagic = byteArrayOf(0x28, 0xb5.toByte(), 0x2f, 0xfd.toByte())
    private const val OUTER_HEADER_SIZE = 30
    private const val MAX_MANIFEST_BYTES = 16L * 1024 * 1024

    fun parse(file: ByteArray): FmvManifest {
        require(file.size > OUTER_HEADER_SIZE) { "File terlalu kecil untuk save FMV" }
        require(file[0] == 0x02.toByte() && file[1] == 0x01.toByte() &&
            String(file, 2, 4, Charsets.US_ASCII) == "fmf.") { "Header FMF/FMV tidak dikenali" }

        val footer = lastIndexOf(file, manifestPrefix)
        require(footer >= OUTER_HEADER_SIZE) { "Footer manifest tidak ditemukan" }
        val sizePos = footer + manifestPrefix.size
        require(sizePos + 4 <= file.size) { "Header ukuran manifest terpotong" }
        val compressedSize = u32(file, sizePos)
        val framePos = sizePos + 4
        require(compressedSize > 0 && compressedSize <= Int.MAX_VALUE && framePos.toLong() + compressedSize == file.size.toLong()) {
            "Ukuran frame manifest tidak cocok dengan panjang file"
        }
        require(file.copyOfRange(framePos, framePos + 4).contentEquals(zstdMagic)) { "Manifest bukan frame Zstandard" }
        val frame = file.copyOfRange(framePos, file.size)
        val plainSize = Zstd.decompressedSize(frame)
        require(plainSize in 1..MAX_MANIFEST_BYTES) { "Ukuran manifest tidak valid: $plainSize" }
        val plain = Zstd.decompress(frame, plainSize.toInt())
        return parseManifest(plain, footer)
    }

    /** Decompress one manifest member into a private app-cache file. Source save stays untouched. */
    fun extractMemberToFile(file: ByteArray, member: FmvMember, output: File): Pair<Long, Int> {
        val startLong = OUTER_HEADER_SIZE.toLong() + member.offset
        val endLong = startLong + member.storedLength
        require(startLong >= OUTER_HEADER_SIZE && endLong <= file.size && endLong >= startLong) {
            "Komponen ${member.name} berada di luar batas file"
        }
        var cursor = startLong.toInt()
        val end = endLong.toInt()
        var written = 0L
        var frames = 0
        output.parentFile?.mkdirs()
        FileOutputStream(output).use { sink ->
            while (written < member.plainLength) {
                val frameSize = zstdFrameSize(file, cursor, end)
                val frame = file.copyOfRange(cursor, cursor + frameSize)
                val declared = Zstd.decompressedSize(frame)
                require(declared in 1..(member.plainLength - written)) {
                    "Ukuran frame Zstandard tidak valid pada ${member.name}: $declared"
                }
                val plain = Zstd.decompress(frame, declared.toInt())
                sink.write(plain)
                written += plain.size
                cursor += frameSize
                frames++
                if (written < member.plainLength) {
                    require(cursor + 4 <= end) { "Pemisah antar-frame terpotong" }
                    val nextFrameLength = u32(file, cursor)
                    require(nextFrameLength > 0 && nextFrameLength <= end - cursor - 4) {
                        "Panjang frame berikutnya tidak valid"
                    }
                    cursor += 4
                }
            }
            require(written == member.plainLength) { "Ukuran hasil dekompresi tidak cocok" }
            require(cursor == end - 4) { "Batas komponen tidak cocok (cursor=$cursor end=$end)" }
        }
        return written to frames
    }

    /** Determine one Zstandard frame boundary from its standard frame/block headers. */
    private fun zstdFrameSize(data: ByteArray, start: Int, limit: Int): Int {
        require(start + 5 <= limit && data[start] == 0x28.toByte() && data[start + 1] == 0xb5.toByte() &&
            data[start + 2] == 0x2f.toByte() && data[start + 3] == 0xfd.toByte()) { "Magic frame Zstandard tidak valid" }
        var p = start + 4
        val descriptor = data[p++].toInt() and 0xff
        require(descriptor and 0x18 == 0) { "Reserved bit pada frame Zstandard terisi" }
        val singleSegment = descriptor and 0x20 != 0
        val checksum = descriptor and 0x04 != 0
        val dictFlag = descriptor and 0x03
        val fcsFlag = descriptor ushr 6
        if (!singleSegment) p += 1 // window descriptor
        p += when (dictFlag) { 0 -> 0; 1 -> 1; 2 -> 2; else -> 4 }
        p += when (fcsFlag) { 0 -> if (singleSegment) 1 else 0; 1 -> 2; 2 -> 4; else -> 8 }
        require(p <= limit) { "Frame header Zstandard terpotong" }
        var last = false
        while (!last) {
            require(p + 3 <= limit) { "Block header Zstandard terpotong" }
            val h = (data[p].toInt() and 0xff) or ((data[p + 1].toInt() and 0xff) shl 8) or ((data[p + 2].toInt() and 0xff) shl 16)
            p += 3
            last = h and 1 != 0
            val blockType = (h ushr 1) and 3
            val blockSize = h ushr 3
            require(blockType != 3) { "Reserved block type pada Zstandard" }
            val payload = if (blockType == 1) 1 else blockSize
            require(payload >= 0 && p.toLong() + payload <= limit.toLong()) { "Payload block Zstandard melewati batas" }
            p += payload
        }
        if (checksum) p += 4
        require(p <= limit) { "Checksum frame Zstandard terpotong" }
        return p - start
    }

    private fun parseManifest(bytes: ByteArray, footer: Int): FmvManifest {
        val r = Reader(bytes)
        val saveName = r.string()
        val topCount = r.u32().toInt()
        require(topCount in 1..10_000) { "Jumlah komponen utama tidak masuk akal: $topCount" }
        val top = ArrayList<FmvMember>(topCount)
        repeat(topCount) { top += r.member(null) }

        val archiveCount = r.u32().toInt()
        require(archiveCount in 0..1_000) { "Jumlah sub-archive tidak masuk akal: $archiveCount" }
        val nested = ArrayList<FmvMember>()
        repeat(archiveCount) {
            val archive = r.string()
            val childCount = r.u32().toInt()
            require(childCount in 0..100_000 && nested.size.toLong() + childCount <= 200_000) {
                "Jumlah entri sub-archive tidak masuk akal"
            }
            repeat(childCount) { nested += r.member(archive) }
        }
        require(r.remaining() >= 4 && r.u32() == 0L) { "Terminator manifest tidak ditemukan" }
        return FmvManifest(saveName, top, nested, footer)
    }

    private class Reader(private val bytes: ByteArray) {
        private var p = 0
        fun remaining() = bytes.size - p
        fun u32(): Long {
            require(p + 4 <= bytes.size) { "Manifest terpotong saat membaca UInt32" }
            val v = ByteBuffer.wrap(bytes, p, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
            p += 4
            return v
        }
        private fun u64(): Long {
            require(p + 8 <= bytes.size) { "Manifest terpotong saat membaca UInt64" }
            val v = ByteBuffer.wrap(bytes, p, 8).order(ByteOrder.LITTLE_ENDIAN).long
            p += 8
            require(v >= 0) { "Offset/ukuran melebihi rentang yang didukung" }
            return v
        }
        fun string(): String {
            val n = u32()
            require(n <= Int.MAX_VALUE && p.toLong() + n <= bytes.size.toLong()) { "String manifest melewati batas" }
            val s = String(bytes, p, n.toInt(), Charsets.UTF_8)
            p += n.toInt()
            return s
        }
        fun member(archive: String?): FmvMember {
            val parts = ArrayList<String>()
            while (true) {
                val part = string()
                parts += part
                if (part.startsWith(".")) break
                require(parts.size < 32) { "Path komponen terlalu dalam" }
            }
            val offset = u64()
            val stored = u64()
            val plain = u64()
            require(p + 16 <= bytes.size) { "Metadata checksum komponen terpotong" }
            p += 16 // opaque stamps/checksums; preserved by future writer, not interpreted here
            return FmvMember(parts.joinToString("/"), offset, stored, plain, archive)
        }
    }

    private fun u32(b: ByteArray, p: Int): Long =
        ByteBuffer.wrap(b, p, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL

    private fun lastIndexOf(haystack: ByteArray, needle: ByteArray): Int {
        for (i in haystack.size - needle.size downTo 0) {
            var ok = true
            for (j in needle.indices) if (haystack[i + j] != needle[j]) { ok = false; break }
            if (ok) return i
        }
        return -1
    }
}

/** TAD is identified only by its observed signature; fields are deliberately not guessed. */
data class TadHeaderInfo(val signature: String, val versionBytes: String, val preambleHex: String)

object TadInspector {
    fun inspect(bytes: ByteArray): TadHeaderInfo? {
        if (bytes.size < 12 || String(bytes, 2, 4, Charsets.US_ASCII) != "tad.") return null
        return TadHeaderInfo(
            signature = "tad.",
            versionBytes = "%02x %02x".format(bytes[0].toInt() and 255, bytes[1].toInt() and 255),
            preambleHex = bytes.take(48).joinToString(" ") { "%02x".format(it.toInt() and 255) }
        )
    }
}
