package com.morepp.fm21editor

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    private val openSaveRequest = 4101
    private lateinit var summary: TextView
    private lateinit var filter: EditText
    private lateinit var memberList: LinearLayout
    private var manifest: FmvManifest? = null
    private var selectedSaveBytes: ByteArray? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xff101318.toInt())
        }
        val title = TextView(this).apply {
            text = "FM21 TOUCH SAVE EDITOR"
            textSize = 22f
            setTextColor(0xfff4f4f4.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "ALPHA 0.2 · READ-ONLY DATABASE EXPLORER"
            textSize = 11f
            setTextColor(0xffb6beca.toInt())
            setPadding(0, 7, 0, 18)
        }
        val open = Button(this).apply {
            text = "PILIH FILE SAVE .FMV"
            setOnClickListener { chooseSave() }
        }
        summary = TextView(this).apply {
            text = "Belum ada save yang dibuka.\n\nPilih file career FM Touch 2021 untuk membaca manifest dan daftar komponen database. File asli tidak akan diubah."
            textSize = 13f
            setTextColor(0xffe0e5ec.toInt())
            setPadding(0, 18, 0, 16)
        }
        filter = EditText(this).apply {
            hint = "Cari komponen, mis. player_stats atau finance"
            setSingleLine(true)
            setTextColor(0xfff4f4f4.toInt())
            setHintTextColor(0xff8f98a5.toInt())
            setOnEditorActionListener { _, _, _ -> renderMembers(text.toString()); false }
        }
        val search = Button(this).apply {
            text = "FILTER KOMPONEN"
            setOnClickListener { renderMembers(filter.text.toString()) }
        }
        memberList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(memberList) }
        root.addView(title)
        root.addView(subtitle)
        root.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(summary)
        root.addView(filter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(search)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun chooseSave() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/x-binary"))
        }
        startActivityForResult(intent, openSaveRequest)
    }

    @Deprecated("Legacy result callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != openSaveRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        summary.text = "Membaca save dan manifest..."
        memberList.removeAllViews()
        Thread {
            val result = runCatching {
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("Tidak bisa membuka file")
                bytes to FmvContainerReader.parse(bytes)
            }
            runOnUiThread {
                result.fold(
                    onSuccess = { (bytes, parsed) ->
                        selectedSaveBytes = bytes
                        manifest = parsed
                        summary.text = buildString {
                            appendLine("SAVE BERHASIL DIBACA")
                            appendLine("Nama: ${parsed.saveName}")
                            appendLine("Ukuran: ${bytes.size.toLong() / 1024 / 1024} MB")
                            appendLine("Komponen utama: ${parsed.topLevel.size}")
                            appendLine("Komponen sub-archive: ${parsed.nested.size}")
                            appendLine("Total komponen: ${parsed.allMembers.size}")
                            appendLine("Footer manifest: ${parsed.footerOffset}")
                            appendLine("\nStatus: inspeksi read-only. Belum ada field yang diubah.")
                        }
                        renderMembers("")
                    },
                    onFailure = { summary.text = "GAGAL MEMBACA SAVE\n${it.message}\n\nFile asli tidak diubah." }
                )
            }
        }.start()
    }

    private fun renderMembers(query: String) {
        val data = manifest ?: return
        memberList.removeAllViews()
        val q = query.trim().lowercase(Locale.ROOT)
        val items = data.allMembers.filter { q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q) || (it.archive?.lowercase(Locale.ROOT)?.contains(q) == true) }
        val header = TextView(this).apply {
            text = "${items.size} komponen ditemukan"
            textSize = 12f
            setTextColor(0xffc6a76a.toInt())
            setPadding(0, 10, 0, 8)
        }
        memberList.addView(header)
        items.forEach { member ->
            val button = Button(this).apply {
                text = "${member.name}\nPlain: ${member.plainLength / 1024} KB  ·  Stored: ${member.storedLength / 1024} KB"
                textSize = 11f
                isAllCaps = false
                setOnClickListener { showMember(member) }
            }
            memberList.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun showMember(member: FmvMember) {
        val bytes = selectedSaveBytes ?: return
        summary.text = "Mengekstrak ${member.name}...\nFile sumber tetap read-only."
        Thread {
            val result = runCatching {
                val safeName = member.name.replace('/', '_').replace('\\', '_')
                val out = java.io.File(cacheDir, "fm21_components/$safeName")
                val (written, frames) = FmvContainerReader.extractMemberToFile(bytes, member, out)
                val head = out.inputStream().use { input -> ByteArray(64).also { n -> input.read(n) } }
                Triple(out, written to frames, head)
            }
            runOnUiThread {
                summary.text = result.fold(
                    onSuccess = { (out, stats, head) ->
                        val tad = TadInspector.inspect(head)
                        buildString {
                            appendLine("COMPONENT EXTRACTED")
                            appendLine("Name: ${member.name}")
                            appendLine("Archive: ${member.archive ?: "(top-level)"}")
                            appendLine("Offset: ${member.offset}")
                            appendLine("Stored: ${member.storedLength} bytes")
                            appendLine("Decompressed: ${stats.first} bytes")
                            appendLine("Zstandard frames: ${stats.second}")
                            appendLine("Cache file: ${out.name}")
                            appendLine("\nHeader: ${tad?.signature ?: "unknown"}")
                            if (tad != null) {
                                appendLine("Observed version bytes: ${tad.versionBytes}")
                                appendLine("Preamble: ${tad.preambleHex}")
                            } else appendLine("First bytes: ${head.joinToString(" ") { "%02x".format(it.toInt() and 255) }}")
                            appendLine("\nStatus: extraction only. Field meanings and editing are not implemented yet.")
                        }
                    },
                    onFailure = { "GAGAL EKSTRAK KOMPONEN\n${it.message}\n\nSave asli tidak diubah." }
                )
            }
        }.start()
    }
}
