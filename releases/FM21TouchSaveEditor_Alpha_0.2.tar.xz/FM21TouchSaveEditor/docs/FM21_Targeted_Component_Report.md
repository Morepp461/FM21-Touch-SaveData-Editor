# FM21 Touch targeted component comparison

Before: `Coach Morepp - Bolton backup.fmv` (21,401,187 bytes), save name `Coach Morepp - Bolton`
After: `Coach Morepp - Bolton.fmv` (21,629,895 bytes), save name `Coach Morepp - Bolton`

Both files were read-only inputs. Component payloads were decompressed independently from their manifest entries.

| Component | Before | After | Identical? | Differing bytes in common-length prefix | First differing offset |
|---|---:|---:|:---:|---:|---:|
| `game_db/.dat` | 69,212,563 | 69,387,047 | No | 55,441,851 | 36 |
| `player_stats/.dat` | 2,792,010 | 2,954,062 | No | 426,359 | 347 |
| `finance_manager/.dat` | 1,490 | 1,490 | Yes | 0 | — |
| `contract_man/.dat` | 708 | 704 | No | 473 | 8 |
| `fix_man/.dat` | 906,590 | 918,245 | No | 569,451 | 219209 |
| `comp_man/.dat` | 611,889 | 611,969 | No | 1,801 | 609951 |
| `comp_history_dt/.cmt` | 3,410,888 | 3,410,888 | No | 12 | 3077808 |
| `comp_history_ls/.dat` | 260,118 | 260,114 | No | 78,189 | 8 |
| `comp_90/.dat` | 261,449 | 261,449 | No | 18,487 | 38635 |
| `award_man/.dat` | 7,464 | 7,464 | No | 182 | 1947 |
| `transfer_man/.dat` | 562,463 | 565,460 | No | 303,882 | 8 |
| `person_record_manager/.dat` | 552,168 | 552,168 | No | 7,881 | 67 |
| `person_db_changes/.cmt` | 12,066 | 12,066 | Yes | 0 | — |
| `player_stats_hist_dt/.cmt` | 149,300 | 151,148 | No | 0 | — |
| `rule_group/.dat` | 125,438 | 126,150 | No | 55,253 | 18587 |
| `starting_club_debt_db/.cmt` | 1,325,958 | 1,325,958 | Yes | 0 | — |
| `comp_hosts/.dat` | 33,092 | 33,092 | Yes | 0 | — |
| `save_game_summary/.dat` | 1,908 | 1,908 | No | 25 | 278 |

## Evidence-based observations

- `finance_manager/.dat` is byte-identical across this one-match comparison. This does not mean it contains no editable budget data; it means the match did not alter that component.
- `player_stats/.dat`, `fix_man/.dat`, `comp_man/.dat`, `transfer_man/.dat`, and competition-history components changed. These are candidates for later schema mapping, not proof that every changed byte is a player or match field.
- `game_db/.dat` changed size and many bytes. Insertions/reordering can shift later data, so a raw byte-difference count is not a meaningful count of changed fields.
- `contract_man/.dat` changed. Contract data may have been updated by normal game progression; the two samples alone do not identify which field changed.
- The report does not assign meanings to unknown numeric fields. CA, PA, player attributes, budgets, prize money and league reputation remain unmapped until validated against controlled edits or additional independent evidence.

## Next controlled experiment

To isolate finances, make a separate backup and change exactly one club financial value in-game (if the game exposes it), then save a third snapshot. Keep all other actions unchanged. Compare only the finance-related components. Do not use this alpha to write modified saves.
