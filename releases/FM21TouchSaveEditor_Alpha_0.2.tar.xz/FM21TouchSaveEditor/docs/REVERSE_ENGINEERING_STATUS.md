# FM21 Touch reverse-engineering status

## Confirmed from the two supplied career saves

- Outer container signature: `02 01 66 6d 66 2e` (`02 01 fmf.`).
- The footer manifest is a Zstandard frame and includes the save name, member paths, offsets, stored lengths, decompressed lengths and 16 opaque bytes per member.
- Each supplied save has 68 top-level members and 784 nested members (852 total).
- All 852 members were independently extracted and their decompressed lengths matched the manifest in both supplied saves.
- Total decompressed member payload: 107,314,935 bytes (pre-match) and 107,929,383 bytes (post-match).
- Many payloads start with `03 01 74 61 64 2e` (`03 01 tad.`). The signature is recorded, but its following fields are not yet semantically decoded.

## Components that changed after one match

`player_stats/.dat`, `fix_man/.dat`, `comp_man/.dat`, `comp_history_dt/.cmt`, `comp_history_ls/.dat`, `comp_90/.dat`, `award_man/.dat`, `transfer_man/.dat`, `person_record_manager/.dat`, `rule_group/.dat`, `contract_man/.dat`, and `save_game_summary/.dat` changed in the byte comparison.

`finance_manager/.dat`, `person_db_changes/.cmt`, `starting_club_debt_db/.cmt`, and `comp_hosts/.dat` were byte-identical in these two snapshots.

## Interpretation limits

- A changed byte range is not necessarily a changed field. Serialization insertions can shift later regions and inflate raw byte-difference counts.
- `finance_manager/.dat` being unchanged after one match does not show that it lacks balances or budgets. It only shows that this event did not modify that component in this pair of snapshots.
- Player CA, PA, attributes, club money, transfer budget, prize money and league reputation have not yet been mapped to verified field offsets.
- No save writer exists yet. The app is read-only and extracted data is cached privately.

## Next evidence needed

For financial fields, a third snapshot should be created after changing exactly one available in-game financial value while keeping all other actions unchanged. For player attributes, use two saves where only one player's one editable attribute is changed in-game, if the game provides such an editor. Compare the relevant component payloads and validate any candidate field against a second independent test before writing a parser rule.
