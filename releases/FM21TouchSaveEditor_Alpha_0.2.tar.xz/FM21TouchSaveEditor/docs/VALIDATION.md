# Validation record

## Supplied FM21 Touch saves

Both supplied saves were parsed with the Python reference reader:

- `Coach Morepp - Bolton backup.fmv`: 68 top-level + 784 nested members; all 852 extracted successfully; 107,314,935 decompressed bytes.
- `Coach Morepp - Bolton.fmv`: 68 top-level + 784 nested members; all 852 extracted successfully; 107,929,383 decompressed bytes.

The Zstandard frame-boundary algorithm now ported into the Kotlin app was independently cross-checked against `ZSTD_findFrameCompressedSize` for every frame in both saves: 1,704 member payloads passed, zero boundary mismatches.

## What this validates

- The manifest parser model and component offset/length interpretation are consistent with both supplied samples.
- The multi-frame member extraction boundary algorithm matches the system Zstandard library on the supplied samples.

## What this does not validate

- Kotlin/Android runtime compilation has not been run in this environment because Android Gradle tooling is unavailable here.
- `tad.` record semantics are not decoded.
- No player, club, financial or competition field has been safely edited.
- No rebuilt `.fmv` has been tested in Football Manager Touch 2021.
