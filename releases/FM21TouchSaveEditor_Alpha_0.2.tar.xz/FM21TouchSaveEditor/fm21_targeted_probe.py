#!/usr/bin/env python3
"""Compare selected FM21 Touch save components without modifying either save."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fm21_touch_container import Zstd, find_manifest, parse_manifest, extract_member

TARGETS = [
    "game_db/.dat", "player_stats/.dat", "finance_manager/.dat", "contract_man/.dat",
    "fix_man/.dat", "comp_man/.dat", "comp_history_dt/.cmt", "comp_history_ls/.dat",
    "comp_90/.dat", "award_man/.dat", "transfer_man/.dat", "person_record_manager/.dat",
    "person_db_changes/.cmt", "player_stats_hist_dt/.cmt", "rule_group/.dat",
    "starting_club_debt_db/.cmt", "comp_hosts/.dat", "save_game_summary/.dat"
]

def load(path: Path, zstd: Zstd):
    raw = path.read_bytes()
    _, manifest = find_manifest(raw, zstd)
    name, top, nested = parse_manifest(manifest)
    return raw, name, {m["name"]: m for m in top + nested}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("before", type=Path)
    ap.add_argument("after", type=Path)
    ap.add_argument("--out", type=Path, default=Path("FM21_Targeted_Component_Report.md"))
    args = ap.parse_args()
    zstd = Zstd()
    a, an, am = load(args.before, zstd)
    b, bn, bm = load(args.after, zstd)
    rows = []
    for name in TARGETS:
        if name not in am or name not in bm:
            continue
        x, xf = extract_member(a, am[name], zstd)
        y, yf = extract_member(b, bm[name], zstd)
        common = min(len(x), len(y))
        changed = sum(x[i] != y[i] for i in range(common))
        first = next((i for i in range(common) if x[i] != y[i]), None)
        rows.append({"name": name, "before": len(x), "after": len(y), "same": x == y,
                     "changed_common_bytes": changed, "first_difference": first,
                     "before_sha256": hashlib.sha256(x).hexdigest(),
                     "after_sha256": hashlib.sha256(y).hexdigest(),
                     "frames_before": xf, "frames_after": yf})
    lines = [
        "# FM21 Touch targeted component comparison",
        "",
        f"Before: `{args.before.name}` ({len(a):,} bytes), save name `{an}`",
        f"After: `{args.after.name}` ({len(b):,} bytes), save name `{bn}`",
        "",
        "Both files were read-only inputs. Component payloads were decompressed independently from their manifest entries.",
        "",
        "| Component | Before | After | Identical? | Differing bytes in common-length prefix | First differing offset |",
        "|---|---:|---:|:---:|---:|---:|"
    ]
    for r in rows:
        lines.append(f"| `{r['name']}` | {r['before']:,} | {r['after']:,} | {'Yes' if r['same'] else 'No'} | {r['changed_common_bytes']:,} | {r['first_difference'] if r['first_difference'] is not None else '—'} |")
    lines += [
        "", "## Evidence-based observations", "",
        "- `finance_manager/.dat` is byte-identical across this one-match comparison. This does not mean it contains no editable budget data; it means the match did not alter that component.",
        "- `player_stats/.dat`, `fix_man/.dat`, `comp_man/.dat`, `transfer_man/.dat`, and competition-history components changed. These are candidates for later schema mapping, not proof that every changed byte is a player or match field.",
        "- `game_db/.dat` changed size and many bytes. Insertions/reordering can shift later data, so a raw byte-difference count is not a meaningful count of changed fields.",
        "- `contract_man/.dat` changed. Contract data may have been updated by normal game progression; the two samples alone do not identify which field changed.",
        "- The report does not assign meanings to unknown numeric fields. CA, PA, player attributes, budgets, prize money and league reputation remain unmapped until validated against controlled edits or additional independent evidence.",
        "", "## Next controlled experiment", "",
        "To isolate finances, make a separate backup and change exactly one club financial value in-game (if the game exposes it), then save a third snapshot. Keep all other actions unchanged. Compare only the finance-related components. Do not use this alpha to write modified saves."
    ]
    args.out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Wrote {args.out}")
    for r in rows:
        print(f"{r['name']}: {r['before']} -> {r['after']} same={r['same']} changed={r['changed_common_bytes']}")

if __name__ == "__main__":
    main()
