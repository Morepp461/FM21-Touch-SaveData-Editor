#!/usr/bin/env python3
"""Validate that every manifest member in the supplied FMV saves decompresses cleanly."""
from pathlib import Path
import argparse, sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from fm21_touch_container import Zstd, find_manifest, parse_manifest, extract_member

p = argparse.ArgumentParser()
p.add_argument('saves', nargs='+', type=Path)
a = p.parse_args()
z = Zstd()
for save in a.saves:
    raw = save.read_bytes()
    _, manifest = find_manifest(raw, z)
    name, top, nested = parse_manifest(manifest)
    total = 0
    for member in top + nested:
        payload, _frames = extract_member(raw, member, z)
        if len(payload) != member['plain_length']:
            raise SystemExit(f"FAIL {save.name}: {member['name']} length mismatch")
        total += len(payload)
    print(f"PASS {save.name}: {name}; {len(top)} top-level + {len(nested)} nested = {len(top+nested)} members; {total:,} decompressed bytes")
